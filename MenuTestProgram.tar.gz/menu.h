/******************************************************************************/
/*Copyright (C) Software Engineering Class 2, SSE@USTC, 2014-2015             */
/*                                                                            */
/* FILE NAME             :   menu.h                                           */
/* PRINCIPAL AUTHOR      :   WangMingliang                                    */
/* SUBSYSTEM NAME        :   MenuProgram                                      */
/* MODULE NAME           :   menu                                             */
/* LANGUAGE              :   C                                                */
/* TARGET ENVIRONMENT    :   ANY                                              */
/* DATE OF FIRST RELEASE :   2014/9/20                                        */
/* DESCRIPTION           :   This is menu.h                                   */
/******************************************************************************/


/*
 * Revision log:
 *
 * Created by WangMingliang, 2014/9/20
 *
 */


#include "linktable.h"

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     10



typedef struct DataNode
{
    tLinkTableNode * pNext;
    char*   cmd;
    char*   desc;
    int     (*handler)();
} tDataNode;

int StartMenu(tLinkTable * head);

int InitMenuData(tLinkTable ** ppLinktable);

tDataNode* FindCmd(tLinkTable * head, char * cmd);

int ShowAllCmd(tLinkTable * head);

int AddCmd(tLinkTable * head, tDataNode * tNode);

int DelCmd(tLinkTable * head, tDataNode *tNode);





