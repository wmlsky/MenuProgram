/******************************************************************************/
/*Copyright (C) Software Engineering Class 2, SSE@USTC, 2014-2015             */
/*                                                                            */
/* FILE NAME             :   test.c                                           */
/* PRINCIPAL AUTHOR      :   WangMingliang                                    */
/* SUBSYSTEM NAME        :   MenuTest                                         */
/* MODULE NAME           :   test                                             */
/* LANGUAGE              :   C                                                */
/* TARGET ENVIRONMENT    :   ANY                                              */
/* DATE OF FIRST RELEASE :   2014/9/27                                        */
/* DESCRIPTION           :   This is test.c                                   */
/******************************************************************************/


/*
 * Revision log:
 *
 * Created by WangMingliang, 2014/9/27
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

#define debug

#define SUCCESS 0
#define FAILURE (-1)
#define MAX 20

int results[MAX] = {1,1,1,1,1,1,1,1,1,1};
char * info[MAX] =
{
    "test report",
    "TC1.1 InitMenuData",
    "TC2.1 FindCmd",
    "TC2.2 FindCmd",
    "TC3.1 AddCmd",
    "TC3.2 AddCmd",
    "TC3.3 AddCmd",
    "TC4.1 DelCmd",
    "TC4.2 DelCmd",
    "TC5.1 ShowAllCmd"
};

int Help()
{
    return 0;
}

tLinkTable * head = NULL;

main()
{
    int i;
    int j = 0;
    tDataNode *p; 
    /*test TC1.1�������ܷ��ʼ��Menu*/
    j++;
    i = InitMenuData(&head);
    if(i == SUCCESS)
    {
        debug("TC1.1 success\n");
        results[j] = 0;
    }
    
    /*test TC2.1:�����ʼ������ڵ�cmd��FindCmd*/
    j++;
    char cmd2_1[CMD_MAX_LEN] = "version";
    p = FindCmd(head, cmd2_1);
    if(p != NULL && (!strcmp(p->cmd, "version")))
    {
        debug("TC2.1 success\n");
        results[j] = 0;    
    }

    /*test TC2.2�����벻���ڵ�cmd��FindCmd*/
    j++;
    char cmd2_2[CMD_MAX_LEN] = "help";
    p = FindCmd(head, cmd2_2);
    if(p == NULL)
    {
        debug("TC2.2 success\n");
        results[j] = 0;
    }

    /*test TC3.1������ԭ���������ڵ���������AddCmd*/
    j++;
    p = (tDataNode*)malloc(sizeof(tDataNode));
    p->cmd = "help";
    p->desc = "Menu List:";
    p->handler = Help;
    i = AddCmd(head, p);
    if(i == SUCCESS && FindCmd(head, "help") != NULL)
    {
        debug("TC3.1 success\n");
        results[j] = 0;
    }

    /*test TC3.2�������������Ѵ��ڵĽ���AddCmd*/
    j++;
    p->cmd = "version";
    p->desc = "Menu Program V1.0";
    p->handler = NULL;
    i = AddCmd(head, p);
    if(i == FAILURE)
    {
        debug("TC3.2 success\n");
        results[j] = 0;
    }

    /*test TC3.3������ս���AddCmd*/
    /*tDataNode * pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode = NULL;*/
    j++;
    free(p);
    i = AddCmd(head, p);
    if(i == FAILURE)
    {
        debug("TC3.3 success\n");
        results[j] = 0;
    }
 
    /*test TC4.1�������������Ѵ��ڵĽ���DelCmd*/
    j++;
    tDataNode * pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "version";
    pNode->desc = "Menu Program V1.0";
    pNode->handler = NULL; 
    i = DelCmd(head, pNode);
    if(i == SUCCESS && FindCmd(head, "version") == NULL)
    {
        printf("sdfd");
        debug("TC4.1 success\n");
        results[j] = 0;
    }

    /*test TC4.2: ����ս���DelCmd*/
    j++;
    i = DelCmd(head, p);
    if(i == FAILURE)
    {
        debug("TC4.2 success\n");
        results[j] = 0;
    }
    
    /*test TC5.1: ShowAllCmd*/
    j++;
    i = ShowAllCmd(head);
    if(i == SUCCESS)
    {
        debug("TC5.1 success\n");
        results[j] = 0;
    }
       
    /* more test case ...*/

    printf("test report:\n");
    for(i=1;i<=j;i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number%d Failure - %s\n",i,info[i]);
        }
        else
        {
            printf("Testcase Number%d Success - %s\n",i,info[i]);
        }
    }
}
