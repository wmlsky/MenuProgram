/******************************************************************************/
/*Copyright (C) Software Engineering Class 2, SSE@USTC, 2014-2015             */
/*                                                                            */
/* FILE NAME             :   menu.c                                           */
/* PRINCIPAL AUTHOR      :   WangMingliang                                    */
/* SUBSYSTEM NAME        :   MenuProgram                                      */
/* MODULE NAME           :   menu                                             */
/* LANGUAGE              :   C                                                */
/* TARGET ENVIRONMENT    :   ANY                                              */
/* DATE OF FIRST RELEASE :   2014/9/20                                        */
/* DESCRIPTION           :   This is menu.c                                   */
/******************************************************************************/


/*
 * Revision log:
 *
 * Created by WangMingliang, 2014/9/20
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

#define SUCCESS 0
#define FAILURE (-1)

int StartMenu(tLinkTable * head)
{   
/* cmd line begins */  
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd > ");
        scanf("%s", cmd);
        tDataNode *p = FindCmd(head, cmd);
        if( p == NULL)
        {
            printf("This is a wrong cmd!\n ");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc); 
        if(p->handler != NULL) 
        { 
            p->handler();
        } 
    }
}

int InitMenuData(tLinkTable ** ppLinktable)
{
    *ppLinktable = CreateLinkTable();
    tDataNode* pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "version";
    pNode->desc = "Menu Program V1.0";
    pNode->handler = NULL; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    return SUCCESS; 
}

tDataNode* FindCmd(tLinkTable * head, char * cmd)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, cmd))
        {
            return  pNode;  
        }
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return NULL;
}

int ShowAllCmd(tLinkTable * head)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return SUCCESS;
}

int AddCmd(tLinkTable * head, tDataNode * tNode)
{
    tDataNode *pNode = (tDataNode *)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd,tNode->cmd))
        {
             return FAILURE;
        }
        pNode = (tDataNode *)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    if(AddLinkTableNode(head,(tLinkTableNode*)tNode) == 0)
    {
        return SUCCESS;
    }
    else
    {
        return FAILURE;
    }
}

int DelCmd(tLinkTable * head, tDataNode *tNode)
{
    tDataNode *pNode = (tDataNode *)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd,tNode->cmd))
        {
            if(DelLinkTableNode(head,(tLinkTableNode*)tNode) == 0)
            {
                return SUCCESS;
            } 
        }
        pNode = (tDataNode *)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return FAILURE;
}



