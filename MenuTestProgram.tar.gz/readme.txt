This is a test program for menu.h.
$ make			#you can build this program
$ ./test		#you can run this program
$ make clean		#you can clean the *.o files and program

