/******************************************************************************/
/*Copyright (C) Software Engineering Class 2, SSE@USTC, 2014-2015             */
/*                                                                            */
/* FILE NAME             :   main.c                                           */
/* PRINCIPAL AUTHOR      :   WangMingliang                                    */
/* SUBSYSTEM NAME        :   MenuProgram                                      */
/* MODULE NAME           :   main                                             */
/* LANGUAGE              :   C                                                */
/* TARGET ENVIRONMENT    :   ANY                                              */
/* DATE OF FIRST RELEASE :   2014/9/20                                        */
/* DESCRIPTION           :   This is main.c                                   */
/******************************************************************************/


/*
 * Revision log:
 *
 * Created by WangMingliang, 2014/9/20
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

main()
{
    tLinkTable * head = NULL;
    InitMenuData(&head);
 
   /* cmd line begins */

    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd > ");
        scanf("%s", cmd);
        tDataNode *p = FindCmd(head, cmd);
        if( p == NULL)
        {
            printf("This is a wrong cmd!\n ");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc); 
        if(p->handler != NULL) 
        { 
            p->handler();
        }
   
    }
}
