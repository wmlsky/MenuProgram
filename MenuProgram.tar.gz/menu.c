/******************************************************************************/
/*Copyright (C) Software Engineering Class 2, SSE@USTC, 2014-2015             */
/*                                                                            */
/* FILE NAME             :   menu.c                                           */
/* PRINCIPAL AUTHOR      :   WangMingliang                                    */
/* SUBSYSTEM NAME        :   MenuProgram                                      */
/* MODULE NAME           :   menu                                             */
/* LANGUAGE              :   C                                                */
/* TARGET ENVIRONMENT    :   ANY                                              */
/* DATE OF FIRST RELEASE :   2014/9/20                                        */
/* DESCRIPTION           :   This is menu.c                                   */
/******************************************************************************/


/*
 * Revision log:
 *
 * Created by WangMingliang, 2014/9/20
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

tDataNode* FindCmd(tLinkTable * head, char * cmd)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, cmd))
        {
            return  pNode;  
        }
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return NULL;
}

int ShowAllCmd(tLinkTable * head)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return 0;
}

int InitMenuData(tLinkTable ** ppLinktable)
{
    *ppLinktable = CreateLinkTable();
    tDataNode* pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "help";
    pNode->desc = "Menu List:";
    pNode->handler = Help;
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "version";
    pNode->desc = "Menu Program V1.0";
    pNode->handler = NULL; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "quit";
    pNode->desc = "Quit from Menu Program V1.0";
    pNode->handler = Quit; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
 
    return 0; 
}

int Help()
{
    tLinkTable * helpHead = NULL;
    InitMenuData(&helpHead);
    ShowAllCmd(helpHead);
    return 0;
}

int Quit()
{
    exit(0);
}
